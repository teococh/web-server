<?php

    echo "Nombre: ".$_GET['nombre'];
    echo "Usuario: ".$_GET['usuario'];
    echo "email: ".$_GET['email'];
    echo "telefono: ".$_GET['telefono'];
    echo "movil: ".$_GET['movil'];
    echo "cp: ".$_GET['cp'];

?>